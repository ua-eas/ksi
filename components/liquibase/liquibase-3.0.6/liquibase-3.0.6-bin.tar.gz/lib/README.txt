Any .jar files placed in this directory will be automatically added to the Liquibase classpath.

Place JDBC drivers, Liquibase extensions and Liquibase dependencies (e.g. snakeyaml) here.
