#include <stdio.h>

void b()
{
    printf ("In function b\n");
}
