#include "regenc.h"
/* dummy for unsupported, statefull encoding */
ENC_DUMMY("UTF-16");
ENC_DUMMY("UTF-32");
